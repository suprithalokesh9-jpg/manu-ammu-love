<!DOCTYPE html>  
<html>  
<head>  
    <title>Manu ❤️ Ammu</title>  
    <style>  
        body {  
            margin: 0;  
            padding: 0;  
            font-family: 'Segoe UI', sans-serif;  
            background: linear-gradient(to bottom, #0f0c29, #302b63, #24243e);  
            color: white;  
            text-align: center;  
            overflow-x: hidden;  
        }  
  
        h1 {  
            margin-top: 30px;  
            font-size: 45px;  
        }  
  
        .heart {  
            font-size: 70px;  
            animation: heartbeat 1s infinite;  
        }  
  
        @keyframes heartbeat {  
            0% { transform: scale(1); }  
            50% { transform: scale(1.2); }  
            100% { transform: scale(1); }  
        }  
  
        .section {  
            margin: 40px auto;  
            max-width: 700px;  
            padding: 20px;  
        }  
  
        .counter {  
            font-size: 25px;  
            font-weight: bold;  
            margin-top: 20px;  
        }  
  
        button {  
            padding: 12px 25px;  
            margin: 10px;  
            border: none;  
            border-radius: 25px;  
            font-size: 16px;  
            cursor: pointer;  
            background: #ff4b7d;  
            color: white;  
        }  
  
        button:hover {  
            background: white;  
            color: #ff4b7d;  
        }  
  
        img {  
            width: 250px;  
            border-radius: 20px;  
            margin-top: 15px;  
            box-shadow: 0 0 20px pink;  
        }  
    </style>  
</head>  
<body>  
  
<h1>Manu ❤️ Ammu</h1>  
<div class="heart">❤️</div>  
  
<div class="section">  
    <h2>🌙 Our Midnight Story</h2>  
    <p>  
        Manu…<br><br>  
        I still remember that midnight when I was just 13 years old.<br>  
        My hands were shaking, my heart was racing…<br>  
        But my love for you was fearless. 💖<br><br>  
        That cute midnight proposal was the beginning of us.<br>  
        And from that day till today… you are my forever.  
    </p>  
</div>  
  
<div class="section">  
    <h2>⏳ Days Since We Met</h2>  
    <div class="counter">  
        We have been together for <span id="days"></span> days ❤️  
    </div>  
</div>  
  
<div class="section">  
    <h2>📸 Our Memory</h2>  
    <!-- Replace photo.jpg with your photo name -->  
    <img src="photo.jpg" alt="Manu and Ammu">  
</div>  
  
<div class="section">  
    <h2>💌 Open When...</h2>  
    <button onclick="letter1()">Open When You Miss Me</button>  
    <button onclick="letter2()">Open When You Feel Sad</button>  
</div>  
  
<div class="section">  
    <h2>💍 Forever Question</h2>  
    <button onclick="proposal()">Click Here Manu 💖</button>  
</div>  
  
<!-- Background Music -->  
<audio autoplay loop>  
    <!-- Replace music.mp3 with your song -->  
    <source src="music.mp3" type="audio/mp3">  
</audio>  
  
<script>  
    // CHANGE THIS DATE to your real first meeting date  
    var startDate = new Date("2015-02-14");  
  
    var today = new Date();  
    var timeDifference = today.getTime() - startDate.getTime();  
    var days = Math.floor(timeDifference / (1000 * 3600 * 24));  
  
    document.getElementById("days").innerHTML = days;  
  
    function letter1() {  
        alert("Manu 💕 Even if I’m not beside you, close your eyes… I’m hugging you tight. Forever your Ammu ❤️");  
    }  
  
    function letter2() {  
        alert("My love… you are stronger than you think. I’m always proud of you. Don’t forget you have Ammu forever 💖");  
    }  
  
    function proposal() {  
        alert("Manu ❤️ I loved you at 13, I love you now, and I will love you forever. Will you stay mine forever? 💍");  
    }  
</script>  
  
</body>  
</html>  
